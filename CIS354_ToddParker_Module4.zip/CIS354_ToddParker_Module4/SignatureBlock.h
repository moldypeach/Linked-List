#ifndef SIGNATUREBLOCK_H
#define SIGNATUREBLOCK_H

class SignatureBlock
{
public:
	static void printHeader();
private:
	static const char star;
	static const char blank;
}; // end SignatureBlock class

#endif